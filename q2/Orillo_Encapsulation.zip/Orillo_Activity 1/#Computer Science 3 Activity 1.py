#Computer Science 3 Activity 1

#Situation 1:
class GameCharacter:
    def __init__(self, username):
        self.username = username #Public attribute

#Situation 2:
class BankAccount:
    def __init__(self, balance):
        self.__balance = balance #Private attribute

#Situation 3:
class Vehicle:
    def __init__(self, engineCode):
        self._engineCode = engineCode #Protected attribute

#Situation 4:
class Student:
    def __init__(self, schoolName):
        self.schoolName = schoolName #Public attribute

#Situation 5:
class VotingSystem:
    def __init__(self, voterID):
        self.__voterID = voterID #Private attribute
