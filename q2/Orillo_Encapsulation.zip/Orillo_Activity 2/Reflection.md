#Using @property makes the code easier to read because we can access and update private attributes like regular variables.
#Instead of using separate get and set methods with parentheses, we can simply use the attribute name.
#This makes code cleaner and easier to understand while still protecting the data.

