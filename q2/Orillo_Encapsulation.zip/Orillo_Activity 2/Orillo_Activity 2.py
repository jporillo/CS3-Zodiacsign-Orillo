class Rectangle:
    def __init__(self, width, height):
        self.__width = width
        self.__height = height

    # ----- getters -----
    @property
    def width(self):
        return f"{self.__width:.1f}cm"

    @property
    def height(self):
        return f"{self.__height:.1f}cm"

    # ----- setters -----
    @width.setter
    def width(self, new_width):
        if new_width > 0:
            self.__width = new_width
        else:
            print("Width must be greater than zero")

    @height.setter
    def height(self, new_height):
        if new_height > 0:
            self.__height = new_height
        else:
            print("Height must be greater than zero")

    # ----- deleters -----
    @width.deleter
    def width(self):
        del self.__width
        print("Width has been deleted")

    @height.deleter
    def height(self):
        del self.__height
        print("Height has been deleted")


rectangle = Rectangle(3, 4)

rectangle.width = 0        # rejected, prints a message
rectangle.width = 5        # accepted
rectangle.height = -1      # rejected, prints a message
rectangle.height = 6       # accepted

print(rectangle.width)     # 5.0cm
print(rectangle.height)    # 6.0cm

del rectangle.width        # Width has been deleted
del rectangle.height       # Height has been deleted
