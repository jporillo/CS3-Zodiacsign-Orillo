class BankAccount:
    def __init__(self, account_number, balance):
        self.__account_number = account_number
        self.__balance = balance

    def set_account_number(self, account_number):
        self.__account_number = account_number
        print(f"Account number set to: {self.__account_number}")

        self.set_account_number(account_number)

    def set_balance(self, balance):
        if balance <= -1:
            print("Balance cannot be negative.")
            return
        else:
            print(f"Balance set to: {balance:.2f}")
            self.__balance = balance
            

    @property
    def account_number(self):
        return self.__account_number

    @property
    def balance(self):
        return self.__balance

if __name__ == "__main__":
    a1 = BankAccount(12345, 1000)
    print("Account 1")
    print(f"Account Number: {a1.account_number}")
    print(f"Balance: {a1.balance:.2f}\n")
    incrementor = -100
    print(f"Update balance to {incrementor}")
    a1.set_balance(incrementor)

    print(f"Account Number: {a1.account_number}")
    print(f"Balance: {a1.balance:.2f}")

    

